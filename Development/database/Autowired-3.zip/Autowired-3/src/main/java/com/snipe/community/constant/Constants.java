package com.snipe.community.constant;

public interface Constants {
	public static String ACCESS_KEY_HEADER = "X-API-KEY";
}
