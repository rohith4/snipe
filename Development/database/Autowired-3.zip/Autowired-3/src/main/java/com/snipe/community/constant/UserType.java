package com.snipe.community.constant;

public enum UserType {
	SUPERADMIN, ADMIN, USER, DOCTOR, PATIENT, STAFF, NURSE
}
