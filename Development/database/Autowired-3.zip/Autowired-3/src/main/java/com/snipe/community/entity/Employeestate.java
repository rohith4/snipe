package com.snipe.community.entity;

public enum Employeestate {

	
	INACTIVE,ACTIVE,DELETED
}
