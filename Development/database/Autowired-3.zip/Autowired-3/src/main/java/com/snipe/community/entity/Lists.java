
package com.snipe.community.entity;

import java.util.List;

public class Lists {
	
	
	private List<Employee> userentity;
 

	public List<Employee> getUserentity() {
		return userentity;
	}

	public void setUserentity(List<Employee> userentity) {
		this.userentity = userentity;
	}

}
