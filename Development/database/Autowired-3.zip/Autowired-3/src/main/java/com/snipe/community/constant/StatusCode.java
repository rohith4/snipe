package com.snipe.community.constant;

public enum StatusCode {
	SUCCESS, ERROR;
}
