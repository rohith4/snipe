package com.snipe.community.constant;

public enum LoginType {
	DHC, GOOGLE, TWITTER, FACEBOOK, AADHAR, LINKEDIN
}
