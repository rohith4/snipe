package com.snipe.community.email;

import java.io.IOException;
import java.util.Properties;
import java.util.Random;



import java.util.Date;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.snipe.community.entity.Employee;
import com.snipe.community.helper.Helper;




/**
 * Servlet implementation class send
 */
public class send extends HttpServlet {
	
	
	
	@Autowired
	private Helper helper;
	
	@Autowired
	private SessionFactory sessionFactory;
	
		public String otp(final String username) throws ServletException, IOException,Exception {


			System.out.println("Generating OTP using random() : ");
			System.out.print("Your OTP is : ");
			String numbers = "0123456789";
			Random rndm_method = new Random();
			int len = 8;
			char[] otp1 = new char[len];
			for (int i = 0; i < len; i++)
			{
				otp1[i] =numbers.charAt(rndm_method.nextInt(numbers.length()));
			}
			System.out.println(otp1);
			String str=new 	String(otp1);	
			//String password="";
			
			
			
			
			
			String host = "smtp.gmail.com";
			String user = "d.chennur@gmail.com";
			String pass = "779_devaraj";
			String to = "d.chennur@gmail.com";
			String from = "d.chennur@gmail.com";
			String subject = "this is a sample message";
			String messageText = "your is test mail";
			boolean sessionDebug = false;

			try {

				Properties props = System.getProperties();

				props.put("mail.smtp.starttls.enable", "true");
				props.put("mail.smtp.host", host);
				props.put("mail.smtp.port", "587");
				props.put("mail.smtp.auth", "true");
				props.put("mail.smtp.starttls.required", "true");

				java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
				Session mailSession = Session.getInstance(props, null);
				mailSession.setDebug(sessionDebug);
				Message msg = new MimeMessage(mailSession);
				msg.setFrom(new InternetAddress(from));
				InternetAddress[] address = { new InternetAddress(to) };
				msg.setRecipients(Message.RecipientType.TO, address);
				msg.setSubject(subject);
				msg.setSentDate(new Date());
				msg.setText(str);
				Transport transport = mailSession.getTransport("smtp");
				transport.connect(host, user, pass);
				transport.sendMessage(msg, msg.getAllRecipients());
				
				
				
				
				
				
	
				  
				
				
				
				
				
				
				
				
				
				
				
				
				transport.close();
				
				System.out.println("getting started");
				/* org.hibernate.Session session1=sessionFactory.getCurrentSession();
				  //  Session session=sessionFactoy.getCurrentSession();
				//	System.out.println(st);
					
				//	logger.info("******UserRegisterDAOImpl.updateLoginStatus**************");
					Criteria crit = session1.createCriteria(Employee.class);
					crit.add(Restrictions.eq("emailId",user));	
					Employee entity = (Employee)crit.uniqueResult();
				
					entity.setPwd(helper.getPasswordEncoded(str,user));
					session1.saveOrUpdate(entity);
				*/
				System.out.println("Message Send Successfully");
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("error::::::::::;;" + e.getMessage());

			}
			return str;

			
			
			
			
		}
		
}
