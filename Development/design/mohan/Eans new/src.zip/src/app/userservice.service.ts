import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';

@Injectable()
export class UserserviceService {

  constructor(private _http: Http) {}
  ans(data) {
    console.log(data);
    return this._http.post('http://localhost:8082/DemoAPI/rest/', data)
    .map(res => res.json());
    }

}
