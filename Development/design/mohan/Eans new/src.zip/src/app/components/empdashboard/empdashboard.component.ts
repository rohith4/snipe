import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { UserserviceService } from '../../userservice.service';



@Component({
  selector: 'app-empdashboard',
  templateUrl: './empdashboard.component.html',
  styleUrls: ['./empdashboard.component.css']
})
export class EmpdashboardComponent implements OnInit {
data: Object = {};

  constructor(private userService: UserserviceService) { }

  ngOnInit() {}
  ans(data) {
    console.log(data);
    this.userService.ans(data)
    .subcribe(
      (data) =>  console.log(data),
      (error) => console.log(error),
    );
  }
}
